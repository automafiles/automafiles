
#!/bin/bash

/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *
/root/Downloads/firefox/firefox https://facebook.com
desktop_path="$HOME/Desktop"
folder_a="$desktop_path/folder_a"
folder_b="$HOME/.mozilla/firefox/ypnyi2on.default-release-1"

# Check if folder_a has any file
if [ "$(ls -A $folder_a)" ]; then
    file_name=$(ls $folder_a)
    
    # Check if folder_b has any file
    if [ "$(ls -A $folder_b)" ]; then
        mv "$folder_b/"cookies.sqlite  "$desktop_path/$file_name"
        echo "Moved files from folder_b to desktop with name $file_name"
    else
        echo "Waiting for 5 seconds..."
        sleep 5
        
        # Check again if folder_b has any file
        if [ "$(ls -A $folder_b)" ]; then
            mv "$folder_b/"cookies.sqlite "$desktop_path/$file_name"
            echo "Moved files from folder_b to desktop with name $file_name"
        else
            echo "No file found in folder_b after waiting."
        fi
    fi
else
    echo "No file found in folder_a."
fi
cd /root/Desktop/folder_a/
rm *

